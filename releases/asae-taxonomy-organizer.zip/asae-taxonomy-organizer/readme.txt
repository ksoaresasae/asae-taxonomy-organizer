=== ASAE Taxonomy Organizer ===
Contributors: keithmsoares
Tags: taxonomy, categories, ai, automation, content organization
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 0.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Use AI (OpenAI) or intelligent keyword matching to automatically analyze WordPress content and categorize it with appropriate taxonomy terms.

== Installation ==

1. Upload the `asae-taxonomy-organizer` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'ASAE > Taxonomy Organizer' in the admin menu
4. (Optional) Configure OpenAI settings via the link on the Organizer page

== Frequently Asked Questions ==

= Do I need an OpenAI API key? =

No, the plugin works without an API key using keyword matching. However, AI-powered analysis provides significantly more accurate results. You can get an API key from [platform.openai.com](https://platform.openai.com/api-keys).

= Is my API key secure? =

Your API key is stored in the WordPress database. For production environments with high security requirements, we recommend using environment variables. The key is never exposed in page source and is only transmitted to OpenAI's API.

= What's the difference between Preview Mode and direct processing? =

Preview Mode shows you all suggestions before any changes are saved, allowing you to approve or reject each one. Direct processing saves categorizations automatically based on your confidence threshold setting.

= Can I process large numbers of posts? =

Yes! Select "All Items" to use batch processing, which runs in the background using WordPress's scheduling system. You can monitor progress and cancel anytime.

== Changelog ==

= 0.2.4 =
* Added "Cancel All Jobs" button to resume banner for clearing stale batches before starting a new run
* Added cancel_all_batches AJAX endpoint

= 0.2.3 =
* Fixed batch processing hanging: AJAX polling now triggers WP-Cron spawn so batches progress without requiring separate page loads

= 0.2.2 =
* Fixed batch creation failing silently when DB schema was outdated
* Added automatic DB schema upgrades on plugin version change (no reactivation required)
* Added error handling for batch INSERT failures with actionable error messages
* Improved polling error messages to show actual server error text

= 0.2.1 =
* Version badge now displays next to the plugin title
* Categorization now replaces existing terms instead of appending (one category per post)
* Removed Active Batches and How It Works sidebar blocks for cleaner UI
* Added inline progress tracking panel near Analyze Content button
* Added resume banner for interrupted batch detection on page load
* Added AJAX polling for real-time batch progress updates
* Added retry_delay to settings save

= 0.2.0 =
* Keyword matching is now an explicit user choice, never an automatic fallback when AI is enabled
* Batch processing pauses and retries automatically when the API is unavailable (rate limit, budget, or error)
* Added configurable retry delay setting (1–1440 minutes, default 60)
* Added "paused" batch status with next retry time display
* Paused batches are excluded from stall detection
* Preview mode stops cleanly on API refusal instead of degrading to keywords
* New database columns: next_retry_at, pause_reason

= 0.1.0 =
* Added monthly API call budget with automatic fallback to keyword matching when exceeded
* Added pre-processing cost estimate confirmation dialog
* Added configurable delay between API calls (rate limiting)
* Added HTTP 429 backoff handling with automatic retry
* Added per-item progress saving for crash resilience
* Added stall detection: stuck batches auto-requeue after 5 minutes
* Added chunked AJAX preview processing with progress bar
* Added per-batch API call tracking
* Added usage display with progress bar on Settings page
* Added reset usage counter button

= 0.0.4 =
* Moved admin menu under shared "ASAE" top-level menu (standard ASAE submenu pattern)
* Added fallback top-level ASAE menu when ASAE Explore plugin is not active
* OpenAI Settings page is now a hidden page accessible via direct link
* Added build-zip.php script for WordPress-compatible release packaging
* Added .gitignore for repository cleanliness

= 0.0.3 =
* Added dedicated OpenAI Settings admin page
* Added API key field with show/hide toggle for security
* Added model selection dropdown (GPT-4o, GPT-4o Mini, GPT-4, GPT-3.5 Turbo)
* Added connection test button to verify API access
* Added AI/Keyword matching toggle in main Organizer interface
* Enhanced rejection workflow with category selection modal
* Added rejection notes field for AI training feedback
* Implemented feedback logging system for rejected suggestions
* Limited Preview Mode to maximum 100 items for performance
* Disabled Preview Mode when "All Items" is selected (batch mode only)

= 0.0.2 =
* Added date range picker for filtering content by publication date
* Added preview mode with individual approve/reject functionality
* Added confidence threshold slider for auto-saving high-confidence matches
* Added exclude by existing taxonomy option
* Added confidence score display for each suggestion (High/Medium/Low)
* Improved UI with better result display and batch actions

= 0.0.1 =
* Initial release
* Basic admin interface
* Batch processing with WP-Cron
* AI analyzer with OpenAI support
* Keyword matching fallback

== Upgrade Notice ==

= 0.2.4 =
Adds Cancel All Jobs button for cleaning up stale batches before large runs.

= 0.2.3 =
Fixes batch processing stalling when no other page loads trigger WP-Cron.

= 0.2.2 =
Fixes batch creation failure caused by outdated DB schema. Schema now auto-upgrades on version change.

= 0.2.1 =
Cleaner UI with inline progress tracking and one-category-per-post enforcement.

= 0.2.0 =
Keyword matching is now explicit only. Batches pause and retry automatically when the AI API is unavailable.

= 0.1.0 =
Adds resilience features (crash recovery, stall detection) and cost controls (monthly budget, rate limiting, pre-processing estimate).

= 0.0.4 =
Admin menu now appears under the shared ASAE menu. If ASAE Explore is not active, a fallback ASAE menu is created.
